---
name: study-assistant
description: Build source-grounded course revision packs and chapter-based study websites from lectures and tutorials, with bilingual exercises, worked solutions, mind maps, mastery checks and weak-topic review. Use for course/exam revision setup or incremental additions to an existing study assistant.
---

# Study Assistant

Turn the user's course materials into an accurate, reusable learning system. Preserve their exam language, excluded folders, scope and previously approved features. Do not assume a syllabus item has been taught merely because it appears in an introductory schedule.

## Establish the course and evidence

- Inventory supplied lectures, tutorials and answer keys without opening excluded folders. Preserve source files. Identify actual lecture subsections, not just filenames. Distinguish uploaded coverage from the instructor's definitive exam scope.
- Record file names, PDF page indices (distinguish printed slide numbers), tutorial question numbers and spreadsheet cells/sheets where useful. Keep stable chapter and concept IDs for updates.
- Extract text, then visually inspect image-only questions, tables, diagrams and suspicious calculations using the available PDF/document skills. An empty text extraction does not mean an empty page.
- Use official tutorial answers when supplied, but independently recompute important numbers. Clearly label original exercises, adaptations, and independently derived solutions when no key exists. If the source contradicts itself, show the discrepancy and chosen assumptions; do not silently copy or silently correct it.
- Do not import generic textbook chapters as if they were taught. If adding helpful extensions, label them as supplemental. Classroom news examples are classroom context, not verified current-events claims.

## Author each chapter

Use the actual lecture subsections. Start with a complete checklist; for each concept include an explanation, English terminology where relevant, assumptions, formula/decision steps, common pitfalls, and a worked example with reasoning. Combine related slides into coherent concepts without dropping examinable distinctions.

Provide a chapter exercise set before the chapter's collected answers. Cover concepts as well as calculations and integrated tutorial problems. Include units, rounding rules, assumptions and interpretive conclusions. Provide a navigable mind map and a portable diagram or handout when useful.

For English exams with Chinese support, default to English questions with Chinese and bilingual toggles. Both language versions must share question IDs, data, alternatives, answers and tolerances; translate the solutions, not just question headings. Keep concept teaching in the user's preferred language.

## Build the learning experience

Read [review-design.md](references/review-design.md) when implementing or modifying a study interface. Honor features already approved; ask for new optional features only when the user requires confirmation. Continue source analysis while necessary design answers are pending. Do not repeatedly ask for approval of an accepted plan.

Use a chapter selector and one active chapter, not a single giant page of all chapters. Separate self-reported mastery from demonstrated quiz performance. Use actual concept/application checks, feedback, a weak-topic queue, retests, and a chapter-end summary. Do not claim one successful quiz proves durable mastery. Free-response solutions require a rubric or clearly labeled self-assessment unless genuine grading exists.

Prefer simple static HTML/JS for browser-local study state. Use the available Sites workflow when the user requests hosting; publish within their authorized scope and preserve audience. Keep the original PDFs local unless uploading them is needed and authorized. Report the actual published URL only after successful deployment.

## Verify and update

- Validate all concept/quiz/exercise links and bilingual fields. Recompute key numerical answers and accounting reconciliations, maintaining precision until the requested rounding step.
- Test wrong answers, successful retests, answer submission in either order, duplicate submissions, language switching with drafts, reload persistence, import/export, and mobile layout. Self-checks must not award tested mastery.
- Preserve stable IDs and user progress when adding later lectures. Document new scope and schema migrations rather than resetting records. The website cannot discover local uploads unless explicitly implemented.
- Deliver the course artifact/link and a concise summary of coverage, known source discrepancies and verification limits. If installing this skill, prepare and validate it locally before requesting any filesystem escalation needed to write the discoverable skills directory.

## Adapt to other courses

Keep the workflow above; replace accounting-specific validation with discipline-appropriate checks. For qualitative courses use scenario discrimination, explanation rubrics and evidence-based comparisons; for quantitative courses test method selection, units, assumptions and multi-step application. Do not reuse an accounting question bank for unrelated subjects.
