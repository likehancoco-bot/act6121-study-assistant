# Chapter study experience

## Data contract

Maintain course identity, source manifest and content version. Each chapter has stable ID, title, actual subsections, concepts, a mind map, exercises and source-correction notes. Each concept has stable ID, source locators, explanation, assumptions, formula, pitfall, worked example, concept question and application variants.

A question carries a single ID, type, paired language text, paired options when applicable, canonical answer, worked solution, numeric unit and explicit tolerance. Use common numerical data for translations. Do not auto-accept empty strings as zero or arbitrarily loosen tolerance to hide inconsistent source numbers. Preserve whole-unit ceilings when asking for minimum feasible quantities.

## Mastery rules

- Record self-check separately from quiz status. Reading, clicking next or revealing an answer does not grant mastery.
- A reasonable default round is a concept question plus an application question, both correct. Mark failure immediately; remove from the weak queue only after a successful retest. Rotate application variants and disclose finite/reused question pools.
- Store attempts, errors, latest result and due date. Rank active weak concepts first, then errors/failure rate; do not interpret a tiny sample as a validated diagnostic score.
- Celebrate a successful round accessibly, honoring reduced-motion preferences. Never block content behind animations or make failures humiliating.
- Offer chapter-end review and then next chapter; avoid permanent lockouts. Untested concepts are not mastered merely because the wrong-answer queue is empty.
- Simple 1/3/7/14-day review dates are acceptable when stated as a simple schedule, not mislabeled as a validated adaptive algorithm. Browser-only dates do not create background reminders.

## Interaction and storage

Keep one active chapter with checklist, study card, chapter practice, mind map and weak-topic review. Put all chapter problems before collected solutions. Preserve drafts across language switches and refreshes. Print/download output should include enough context and separate answers.

Local storage must handle unavailable storage, corrupted data and schema changes. Provide validated import/export. Warn immediately before replacing progress on import. Keep uploaded strings escaped; don't insert imported HTML. State clearly that local progress does not synchronize between devices.

## Acceptance scenarios

1. Start untested; self-check a concept; tested mastery remains zero.
2. Submit a wrong answer; weak flag appears and error increments once.
3. Submit question two before one; no early success or unlock.
4. Resubmit already graded question; no duplicate credit/error.
5. Read again and pass a changed application; weak status clears and celebration/due date appear.
6. Reload and switch language; records and drafts persist.
7. Export, validate/import a backup; reject wrong course, malformed numbers and invalid records.
8. Complete chapter; list unresolved and untested concepts distinctly.
9. Add a chapter retaining existing IDs; old progress survives.
10. Check small screen, keyboard focus, reduced motion, diagram readability and complete downloads.
